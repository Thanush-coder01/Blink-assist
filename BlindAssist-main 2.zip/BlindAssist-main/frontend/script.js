let video = document.getElementById("video");
let running = false;
let stream;

async function startDetection(){

    // unlock speech synthesis
    window.speechSynthesis.cancel();

    stream = await navigator.mediaDevices.getUserMedia({
        video: {
            facingMode: { ideal: "environment" }
        }
    });

    video.srcObject = stream;

    running = true;

    detectLoop();
}


function stopDetection(){

    running = false;

    if(stream){
        stream.getTracks().forEach(track => track.stop());
    }
}

async function detectLoop(){

    if(!running) return;

    const canvas = document.createElement("canvas");

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");

    ctx.drawImage(video,0,0);

    const blob = await new Promise(resolve =>
        canvas.toBlob(resolve,"image/jpeg")
    );

    let formData = new FormData();
    formData.append("file",blob);

    const response = await fetch("/detect",{
        method:"POST",
        body:formData
    });

    const data = await response.json();
    //if(data.warning ){ && data.warning !== lastMessage

        console.log("Warning received:", data.message);
    
        lastMessage = data.message;
    
        document.getElementById("warning").innerText = data.message;
    
        speak(data.message);
    //}
    

    setTimeout(detectLoop,1500); // faster interval
}

function speak(message){

    let speech = new SpeechSynthesisUtterance(message);

    speech.rate = 1;
    speech.pitch = 1;

    window.speechSynthesis.speak(speech);
}


let lastMessage = "";
//if(data.warning && data.warning !== lastMessage){

//    lastMessage = data.warning;

//    speak(data.warning);

//    document.getElementById("warning").innerText = data.warning;
//}

let currentFacing = "environment";

async function switchCamera(){

    stopDetection();

    currentFacing = currentFacing === "environment" ? "user" : "environment";

    stream = await navigator.mediaDevices.getUserMedia({
        video:{
            facingMode: currentFacing
        }
    });

    video.srcObject = stream;

    running = true;

    detectLoop();
}
