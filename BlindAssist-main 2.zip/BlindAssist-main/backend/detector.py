from ultralytics import YOLO
from PIL import Image
import io

model = YOLO("yolov8n.pt")

DANGER_OBJECTS = [
    "person",
    "car",
    "truck",
    "bus",
    "motorcycle",
    "bicycle",
    "chair",
    "bench",
    "dog",
    "cat",
    "stairs",
    "door"
]

responses = {
    "person": "person ahead",
    "car": "Vehicle ahead",
    "truck": "Large vehicle ahead",
    "motorcycle": "bike ahead",
    "bicycle": "Bicycle ahead",
    "chair": "Obstacle ahead",
    "bench": "Bench in your path",
    "dog": "Animal ahead"
}

async def detect_obstacles(file):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents))

    results = model(image)

    for r in results:
        for box in r.boxes:
            cls = int(box.cls)
            label = r.names[cls]

            if label in responses:
                print(responses[label])
                return {responses[label]}

    return "Path clear"
